<?php
session_start();
/*password database*/
if ($_SERVER['REMOTE_ADDR'] == '::1') {
    $con = mysqli_connect('localhost', 'Pass BD', '', 'Pas USER');
} else {
    $con =  mysqli_connect('localhost', /*user*/'', /*password*/ '', /*database*/'');
}
