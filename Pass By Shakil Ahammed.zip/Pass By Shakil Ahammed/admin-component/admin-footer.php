
</body>
</html>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js"></script>
   
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<script src="./admin-component/script.js"></script>
<script src="./admin-component/blueRex.js"></script>
<script>
    $(document).ready(function () {
        $('#data-table1').DataTable({
            processing: true,
            serverSide: true,
            ajax: './admin-component/table-api-1.php',
            columnDefs: [
            {
                render: function (data, type, row) {
                    let c =  new Date(data).toDateString()
                    return c
                },
                targets: 3,
            },
            {
                render: function (data, type, row) {
                    c = `<div class='d-flex justify-content-between'>
                    <button  onclick="handleDelete(${data})" class="btn btn-danger m-1">
                        Delete
                    </button>
                    
                    <button onclick="handleEdit('${data}', title='${row[1]}', token='${row[2]}')" class="btn btn-warning m-1" data-toggle="modal" data-target="#abcmodal">
                        Update
                    </button> </div>
                                    `
                    return c
                },
                targets: 4,
            },
            { visible: false, targets: [] },
        ],
        });
        © Shakil Ahammed<?php
    $copyYear = 2023; // Set your website start date
    $curYear = date('Y'); // Keeps the second year updated
      echo $copyYear . (($copyYear != $curYear) ? '-' . $curYear : '');
  ?> Copyright
    });
</script>