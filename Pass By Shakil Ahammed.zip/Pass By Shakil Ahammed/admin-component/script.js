const handleDelete = async (id) => {
  console.log(id);
  let c = confirm("Do you want to delete this item!");
  if (c) {
    await blueRex
      .get("./admin-component/api.php?delete=" + id)
      .then((e) => {
        let res = e;
        console.log(res);
        if (res == "success") {
          window.location.href = window.location.href;
        }
      })
      .catch((e) => console.log(e));
  }
};
function handleEdit(id, title = "", token = "") {
  console.log(id, title);
  if (confirm("You want to edit this!")) updateForm(id, title, token);
}

const updateForm = (id, title, token) => {
  console.log("asdfljas;ldfj");

  let html = `
  <div class="modal fade" id="abcmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="false">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">${"Edit Password"}</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method='POST' action='./admin-component/api.php'>
              <input type="hidden" value='${id}' name="file-id"/>
                <div class="form-group">
                    <label for="exampleInputEmail1">file password</label>
                    <input type="text" name='title' value="${title}" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter file password...">
                </div>
                <div class="form-group">
                    <label for="pass1">file title</label>
                    <input type="text"  value="${token}" name='password' class="form-control" id="pass1" placeholder="enter file title">
                </div>
               
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  <button type="submit" name='edit-file' value=1 class="btn btn-primary">Add</button>
                </div>
        </form>
      </div>
    </div>
  </div>

  
  `;
  const k = document.querySelector("#modalabc");
  k.innerHTML = html;
};
