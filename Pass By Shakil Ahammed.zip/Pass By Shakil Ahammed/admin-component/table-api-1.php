<?php

$table = 'res_doc_token_';
$primaryKey = 'id';
$columns = array(
    array( 'db' => 'id', 'dt' => 0 ),
    array( 'db' => 'title',  'dt' => 1 ),
    array( 'db' => 'token',   'dt' => 2 ),
    array( 'db' => 'createdAt',     'dt' => 3 ),
    array( 'db' => 'id',     'dt' => 4 ),
);
$sql_details = array(
    'user' => '',
    'pass' => '',
    'db'   => '',
    'host' => 'localhost'
);
require('./ssp.class.php' );
echo json_encode(
    SSP::simple( $_GET, $sql_details, $table, $primaryKey, $columns )
);