<?php 
require_once('db.php');
if(isset($_POST['edit-file'])){
    $title = $_POST['title'];
    $pass = $_POST['password'];
    $id = $_POST['file-id'];
    $sql = "UPDATE `res_doc_token_` SET `title`='$title', `token`='$pass' WHERE `id` = $id";
    $q = $con->query($sql);
    header('location:../admin.php?message=Successfully Updated!');
}
if(isset($_POST['add-new'])){
    $title = $_POST['title'];
    $pass = $_POST['password'];
    $sql = "select * from res_doc_token_ where title = '$title'";
    $q = $con->query($sql);
    if($q->num_rows > 1){
        header('location:../admin.php?message=file password already exist!');
    }else{
        $sql = "INSERT INTO res_doc_token_(title, token) VALUES('$title', '$pass')";
        $q = $con->query($sql);
        header('location:../admin.php?message=successfully added!');
    }
}
if(isset($_GET['delete'])){
    $id = $_GET['delete'];
    $sql = "DELETE FROM res_doc_token_ WHERE id = $id";
    $q = $con->query($sql);
    exit('success');
}