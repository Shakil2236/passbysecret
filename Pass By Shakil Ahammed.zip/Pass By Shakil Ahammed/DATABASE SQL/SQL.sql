-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 08, 2023 at 03:41 AM
-- Server version: 10.3.39-MariaDB-cll-lve
-- PHP Version: 8.1.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gsmsecre_filepass`
--

-- --------------------------------------------------------

--
-- Table structure for table `res_doc_token_`
--

CREATE TABLE `res_doc_token_` (
  `id` int(11) NOT NULL,
  `title` varchar(512) NOT NULL,
  `token` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `res_doc_token_`
--

INSERT INTO `res_doc_token_` (`id`, `title`, `token`, `createdAt`) VALUES
(164, 'shail2236', 'Redmi_9C_NFC angelica NV Ram', '2023-07-05 22:26:19'),
(163, 'shakil2236', 'Rev2_Redmi_9A angelica nv Ram', '2023-07-05 22:12:50');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `res_doc_token_`
--
ALTER TABLE `res_doc_token_`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `res_doc_token_`
--
ALTER TABLE `res_doc_token_`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=180;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
